<?php
/**
 * Created by PhpStorm.
 * User: xiangxn
 * Date: 2017/11/8
 * Time: 2:18
 */

?>
<div class="wrap">
    <h2><?php _e('YOYOW-Auth',YYW_KEY_DOMAIN)?>
        <small style="font-size:14px;padding-left:8px;color:#666">
            <?php
            $plugin_data = get_plugin_data(dirname(__FILE__) . '\\yoyowauth.php');
            echo 'v'.$plugin_data['Version'];
            ?>
        </small>
    </h2>
    <form action="options.php" method="post">
        <?php
        settings_fields( 'yyw_options_group' );
        ?>
        <table class="form-table">

            <tr valign="top">
                <td valign="top" width="20%"><strong><?php _e( 'Show Button', YYW_KEY_DOMAIN ); ?></strong></td>
                <td>
                    <input name="<?php echo YYW_OP_NAME?>[show_button]" id="<?php echo YYW_OP_NAME?>[show_button]" type="checkbox" value="1" <?php checked(yyw_op('show_button'),1);?> />
                </td>
            </tr>
            <tr valign="top">
                <td valign="top" width="20%"><strong><?php _e( 'API Server', YYW_KEY_DOMAIN ); ?></strong></td>
                <td>
                    <input name="<?php echo YYW_OP_NAME?>[api_url]" id="<?php echo YYW_OP_NAME?>[api_url]" class="regular-text" value="<?php echo yyw_op('api_url')?>" />
                </td>
            </tr>
            <tr valign="top">
                <td valign="top" width="20%"><strong><?php _e( 'Faucet Server', YYW_KEY_DOMAIN ); ?></strong></td>
                <td>
                    <input name="<?php echo YYW_OP_NAME?>[faucet_url]" id="<?php echo YYW_OP_NAME?>[faucet_url]" class="regular-text" value="<?php echo yyw_op('faucet_url')?>" />
                </td>
            </tr>
            <tr valign="top">
                <td valign="top" width="20%"><strong><?php _e( 'Nodejs Server', YYW_KEY_DOMAIN ); ?></strong></td>
                <td>
                    <input name="<?php echo YYW_OP_NAME?>[node_auth_url]" id="<?php echo YYW_OP_NAME?>[node_auth_url]" class="regular-text" value="<?php echo yyw_op('node_auth_url')?>" />
                </td>
            </tr>
            <tr valign="top">
                <td valign="top" width="20%"><strong><?php _e( 'Platform Id', YYW_KEY_DOMAIN ); ?></strong></td>
                <td>
                    <input name="<?php echo YYW_OP_NAME?>[platform_id]" id="<?php echo YYW_OP_NAME?>[platform_id]" class="regular-text" value="<?php echo yyw_op('platform_id')?>" />
                </td>
            </tr>
            <tr valign="top">
                <td valign="top" width="20%"><strong><?php _e( 'Secondary Key', YYW_KEY_DOMAIN ); ?></strong></td>
                <td>
                    <input name="<?php echo YYW_OP_NAME?>[secondary_key]" id="<?php echo YYW_OP_NAME?>[secondary_key]" class="regular-text" value="<?php echo yyw_op('secondary_key')?>" />
                </td>
            </tr>
        </table>
        <?php submit_button();?>
    </form>
</div>
