<?php
/*
Plugin Name: YOYOW-Auth
Plugin URI: https://yoyow.org
Description: 提供YOYOW区块链账号的授权登录
Version: 0.2
Author: YOYOW
Author URI: https://yoyow.org
License: MIT
*/

/*
    Copyright (C) 2017 YOYOW.

    The MIT License

    Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
    documentation files (the "Software"), to deal in the Software without restriction, including without limitation
    the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
    and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
    INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
    DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH
    THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */


define('YYW_OP_NAME','yoyow_options');
define('YYW_KEY_DOMAIN','yoyow-auth');

if(!session_id()) session_start();
$GLOBALS[YYW_OP_NAME] = get_option(YYW_OP_NAME);

//init
add_action('init', 'yyw_init', 1);
function yyw_init() {
    load_plugin_textdomain( YYW_KEY_DOMAIN, '', dirname( plugin_basename( __FILE__ ) ) . '/lang' );
    $GLOBALS['which_arr'] = array(
        'login'=>'login',
        'update'=>'update',
        'unbind'=>'unbind'
    );
    if (isset($_GET['action'])) {
        $yyw = new YOYOW_Auth();
        if($_GET['action']=='login'){
            $yyw->login();
        }else if($_GET['action']=='callback'){
            if(!isset($_GET['yoyow'])||!isset($_GET['time'])||!isset($_GET['sign'])){
                header('Location:'.home_url());
                exit();
            }
            $yyw->callback($_GET['yoyow'],$_GET['time'],$_GET['sign'],$_GET['state']);
        }else if($_GET['action']=='update'){

        }else if($_GET['action']=='unbind'){
            $yyw->unbind_user($_GET['state']);
        }
    }
}

register_activation_hook( __FILE__, 'yyw_activation' );
function yyw_activation(){
    if(!$GLOBALS[YYW_OP_NAME]) update_option(YYW_OP_NAME, array(
        'show_button'    =>1,
        'api_url'	       => 'http://localhost:3000',
        'platform_id'    => '232124520'
    ));
}

register_uninstall_hook( __FILE__, 'yyw_uninstall' );
function yyw_uninstall(){
    delete_option(YYW_OP_NAME);
}

function yyw_op($op_key,$op_val=NULL){
    if(isset($GLOBALS[YYW_OP_NAME]) && isset($GLOBALS[YYW_OP_NAME][$op_key])){
        return isset($op_val) ? $GLOBALS[YYW_OP_NAME][$op_key]==$op_val : $GLOBALS[YYW_OP_NAME][$op_key];
    }
    return '';
}

//admin setting
add_action( 'admin_init', 'yyw_admin_init' );
function yyw_admin_init() {
    register_setting( 'yyw_options_group', YYW_OP_NAME );
}

add_action('admin_menu', 'yyw_options_add_page');
function yyw_options_add_page() {
    if(!current_user_can('manage_options')){
        remove_menu_page('index.php');
    }else{
        add_options_page('YOYOW-Auth','YOYOW-Auth', 'manage_options', 'yoyow-auth/yoyowauth-options.php') ;
    }
}

//script & style
add_action( 'wp_enqueue_scripts', 'yyw_style', 100 );
add_action( 'login_enqueue_scripts', 'yyw_style' );
function yyw_style() {
    wp_enqueue_style( 'yyw-style', plugins_url('/styles/yywauth.css', __FILE__) );
    wp_enqueue_script( 'yyw-sdk-script', plugins_url('/scripts/yoyow-browser-sdk.js', __FILE__), array());
    wp_enqueue_script( 'yyw-script', plugins_url('/scripts/yoyowauth.js', __FILE__), array(), '', true );
}

function yyw_login_button_show(){
    if(yyw_op("show_button",1)) {
        return "<div class='yyw_login_button' onclick='yyw_login_button_click()' title='" . __("Login with YOYOW", YYW_KEY_DOMAIN) . "'></div>";
    }
    return "";
}


require_once __DIR__.'/tool/V8JsNodeModuleLoader.php';
require_once __DIR__.'/tool/NativeFileAccess.php';
//CLASS
class YOYOW_Auth{
    protected $api_url = null;
    protected $platform_id = null;

    public function __construct(){
        $this->api_url = $GLOBALS[YYW_OP_NAME]['api_url'];
        $this->platform_id = $GLOBALS[YYW_OP_NAME]['platform_id'];
    }

    function get_remote_json($url){
        $response = wp_remote_get($url);
        $body = wp_remote_retrieve_body($response);
        if(preg_match('/\{(.*)\}/', $body, $matches)) {
            $msg = json_decode(trim($matches[0]));
            if ($msg->code == 0) {
                return $msg->data;
            }else{
                //记录错误code
            }
        }
        return array();
    }
    /**
     * 登录请求，跳转到YOYOW钱包
     */
    function login(){
        $url = $this->api_url . '/auth/sign';
        $yyw_sign = $this->get_remote_json($url);
        if(isset($yyw_sign->platform)&&isset($yyw_sign->sign)&&isset($yyw_sign->time)&&$yyw_sign->platform==$this->platform_id){
            //可以在这里记录成功状态
        }else{
            //可以在这里记录错误
            exit();
        }

        $params = array(
            'platform'=>$this->platform_id,
            'time'=>$yyw_sign->time,
            'which'=>'Login',
            'sign'=>$yyw_sign->sign,
            'state'=>$_GET['state'],
            'redirect'=>home_url('/').'?action=callback'
        );

        header('Location:http://demo.yoyow.org:8000/#/authorize-service?'.http_build_query($params));
        exit();
    }

    /**
     * 处理回调
     * @param $yoyow 要登录的yoyow账号
     * @param $time 时间戳
     * @param $sign 签名
     * @param $state 原样传回的页面状态
     */
    function callback($yoyow,$time,$sign,$state){
        $name = 'yoyo'.$yoyow;
        $url = $this->api_url . '/auth/verify?yoyow='. $yoyow . '&time=' . $time . '&sign=' . $sign;
        $verify = $this->get_remote_json($url);

        if(isset($verify->verify)&&$verify->verify==true){
            $name = $verify->name;
            $newuser = array(
                'nickname' => $yoyow,
                'display_name' => $name,
                'user_url' => '',
                'user_email' => $yoyow.'@yoyow.org'
            );
            if (is_user_logged_in()) {
                $wpuid = get_current_user_id();
                if ( $this->isbind($yoyow)) {
                    $this->close(__('This account has been bound with other user.',YYW_KEY_DOMAIN));
                }
            }else{
                $wpuid = $this->isbind($yoyow);
                if (!$wpuid) {
                    $wpuid = username_exists($yoyow);
                    if(!$wpuid){
                        if(email_exists($newuser['user_email'])) $this->close(sprintf(__('This email [%s] has been registered by other user.',YYW_KEY_DOMAIN),$newuser['user_email']));
                        $userdata = array(
                            'user_pass' => wp_generate_password(),
                            'user_login' => $yoyow
                        );
                        $userdata = array_merge($userdata, $newuser);
                        if(!function_exists('wp_insert_user')){
                            include_once( ABSPATH . WPINC . '/registration.php' );
                        }
                        $wpuid = wp_insert_user($userdata);
                    }
                }
            }
            if($wpuid){
                update_user_meta($wpuid, 'yyw_bind', $yoyow);
                wp_set_auth_cookie($wpuid, true, false);
                wp_set_auth_cookie($wpuid, true, true);
                wp_set_current_user($wpuid);
            }
            $back = isset($state) ? $state : home_url();
            header('Location:'.$back);
            exit();
        }
        exit();
    }

    /**
     * 解绑定yoyow账号和本地账号关系
     */
    function unbind_user($state){
        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            delete_user_meta($user -> ID, 'yyw_bind');
            $back = isset($state) ? $state : home_url();
            header('Location:'.$back);
        }
        exit();
    }

    /**
     * 更新用户授权
     */
    function update(){

    }

    function close($info){
        wp_die($info);
        exit();
    }

    function isbind($yoyow_uid) {
        global $wpdb;
        $bid = $wpdb -> get_var($wpdb -> prepare("SELECT user_id FROM $wpdb->usermeta um WHERE um.meta_key='%s' AND um.meta_value='%s'", 'yyw_bind', $yoyow_uid));
        return $bid;
    }
}
?>