=== WP-YOYOW-AUTH ===
Contributors: YOYOW
Tags: YOYOW, auth
Requires at least: 4.7
Tested up to: 4.7
Stable tag: 0.2

== Description ==

= Usage =
1. git clone https://github.com/yoyow-org/yoyow-node-sdk.git
2. cd yoyow-node-sdk/examples/yoyow-authorize
3. npm install
4. edit conf/config.js
5. npm start
6. install yoyow-auth.zip in wordpress.
7. setting "API Server" and "Platform Id"