=== WP-YOYOW-AUTH ===
Contributors: YOYOW
Tags: YOYOW, auth
Requires at least: 4.7
Tested up to: 4.7
Stable tag: 0.1

== Description ==

= Usage =
1.install [v8js](https://github.com/phpv8/v8js/blob/php7/README.Linux.md)

2.Add tags to the location you want `<?php echo yyw_login_button_show();?>`