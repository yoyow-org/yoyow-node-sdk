<?php

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_common_member_yoyowauth extends discuz_table{
    private $_fields;

    public function __construct() {
        $this->_table = 'common_member_yoyowauth';
        $this->_pk = 'uid';
        $this->_fields = array('uid', 'yoyow', 'bindtime');
        $this->_pre_cache_key = 'common_member_yoyowauth_';
        $this->_cache_ttl = 0;

        parent::__construct();
    }

    public function fetch_by_uid($uid){
        return DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array($this->_table, $uid));
    }

    public function fetch_by_yoyow($yoyow){
        return DB::fetch_first('SELECT * FROM %t WHERE yoyow=%s', array($this->_table, $yoyow));
    }
}
