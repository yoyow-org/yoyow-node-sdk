<?php


//CLASS
class YOYOW_Auth{
    protected $api_url = null;
    protected $platform_id = null;

    public function __construct(){
        global $_G;
        $config = $_G['cache']['plugin']['yoyowauth'];
        $this->api_url = $config['api_url'];
        $this->platform_id = $config['platform_id'];

    }
    function get_remote_json($url){
        $response = dfsockopen($url);
        $body = $response;
        if(preg_match('/\{(.*)\}/', $body, $matches)) {
            $msg = json_decode(trim($matches[0]));
            if ($msg->code == 0) {
                return $msg->data;
            }else{
                //记录错误code
            }
        }
        return array();
    }

    /**
     * 登录请求，跳转到YOYOW钱包
     */
    function login(){
        global $_G;
        $url = $this->api_url . '/auth/sign';
        $yyw_sign = $this->get_remote_json($url);
        if(isset($yyw_sign->platform)&&isset($yyw_sign->sign)&&isset($yyw_sign->time)&&$yyw_sign->platform==$this->platform_id){
            //可以在这里记录成功状态
        }else{
            //可以在这里记录错误
            dexit();
        }

        $params = array(
            'platform'=>$this->platform_id,
            'time'=>$yyw_sign->time,
            'which'=>'Login',
            'sign'=>$yyw_sign->sign,
            'state'=>$_GET['state'],
            'redirect'=>$_G['siteurl'].'plugin.php?id=yoyowauth:login&op=callback'
        );

        dheader('Location:http://demo.yoyow.org:8000/#/authorize-service?'.http_build_query($params));
        dexit();
    }

    /**
     * 处理回调
     * @param $yoyow 要登录的yoyow账号
     * @param $time 时间戳
     * @param $sign 签名
     * @param $state 原样传回的页面状态
     */
    function callback($yoyow,$time,$sign,$state){
        global $_G;
        $name = 'yoyo'.$yoyow;
        $url = $this->api_url . '/auth/verify?yoyow='. $yoyow . '&time=' . $time . '&sign=' . $sign;
        $verify = $this->get_remote_json($url);

        if(isset($verify->verify)&&$verify->verify==true){
            $name = $verify->name;
            if($_G['uid']) {
                $current_yyw_member = C::t('#yoyowauth#common_member_yoyowauth')->fetch_by_uid($_G['uid']);
                if ($_G['member']['conisbind'] && $current_yyw_member['yoyow'] && $yoyow != $current_yyw_member['yoyow']) {
                    showmessage('yoyowauth:yyw_register_bind_already');
                } else {
                    $tmp = array(
                        'uid' => $_G['uid'],
                        'yoyow' => $yoyow
                    );
                    if (empty($current_yyw_member)) {
                        C::t('#yoyowauth#common_member_yoyowauth')->insert($tmp);
                    }
                    if($_G['member']['conisbind'] != '1') {
                        C::t('common_member')->update($_G['uid'], array('conisbind' => '1'));
                        showmessage('yoyowauth:yyw_register_bind_success',dreferer());
                    }
                }
                showmessage('yoyowauth:yyw_login_success',dreferer());
            }else{
                $current_yyw_member = C::t('#yoyowauth#common_member_yoyowauth')->fetch_by_yoyow($yoyow);
                if(!isset($current_yyw_member['uid'])){
                    $uid = $this->dz_reg($yoyow,1,8);
                    if(!$uid) {
                        dsetcookie('yyw_account',$yoyow);
                        dsetcookie('yyw_time',$time);
                        dsetcookie('yyw_sign',$sign);
                        $referer = urlencode($_G['siteurl'].'plugin.php?id=yoyowauth:login&op=regcallback');
                        dheader('location: '.$_G['siteurl'].'member.php?mod='.$_G['setting']['regname'] . '&defaultusername=yoyow' . $yoyow . '&referer='.$referer);
                        dexit();
                    }
                    C::t('#yoyowauth#common_member_yoyowauth')->insert(array(
                        'uid' => $_G['uid'],
                        'yoyow' => $yoyow
                    ));
                    C::t('common_member')->update($_G['uid'], array('conisbind' => '1'));
                    showmessage('yoyowauth:yyw_register_bind_success',dreferer());
                }else{
                    $this->dz_login($current_yyw_member);
                }
            }
        }else{
            showmessage('yoyowauth:yyw_verify_failed',dreferer());
        }
    }

    /**
     * 解绑定yoyow账号和本地账号关系
     */
    function unbind_user(){
        global $_G;
        if($_G['uid']) {
            require_once libfile('function/member');
            C::t('#yoyowauth#common_member_yoyowauth')->delete($_G['uid']);
            C::t('common_member')->update($_G['uid'], array('conisbind' => '0'));
            clearcookies();
            showmessage('yoyowauth:yyw_message_unbinded', dreferer());
        }
        dexit();
    }

    /**
     * 更新用户授权
     */
    function update(){

    }

    function close($info){

        dexit();
    }

    function isbind($yoyow_uid) {

    }

    function dz_login($yyw_member){
        global $_G;
        if(!($member = getuserbyuid($yyw_member['uid'], 1))) {
            showmessage("登录失败");
        } else {
            if(isset($member['_inarchive'])) {
                C::t('common_member_archive')->move_to_master($member['uid']);
            }
        }
        require_once libfile('function/member');
        $cookietime = 1296000;
        setloginstatus($member, $cookietime);

        loadcache('usergroups');
        $usergroups = $_G['cache']['usergroups'][$_G['groupid']]['grouptitle'];
        $param = array('username' => $_G['member']['username'], 'usergroup' => $_G['group']['grouptitle']);

        C::t('common_member_status')->update($yyw_member['uid'], array('lastip'=>$_G['clientip'], 'lastvisit'=>TIMESTAMP, 'lastactivity' => TIMESTAMP));
        dsetcookie('stats_qc_login', 3, 86400);
        $ucsynlogin = '';
        if($_G['setting']['allowsynlogin']) {
            loaducenter();
            $ucsynlogin = uc_user_synlogin($_G['uid']);
            showmessage('login_succeed', '', $param, array('extrajs' => $ucsynlogin));
        }else{
            showmessage('yoyowauth:yyw_login_success', dreferer());
        }
    }

    function dz_reg($yoyow,$return=0,$groupid = 0){
        global $_G;
        if(!$yoyow) {
            return;
        }
        loaducenter();
        $password = md5(random(10));
        $email = $yoyow.'@yoyow.org';
        $username = 'yoyow' . $yoyow;
        $uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
        if($uid <= 0) {
            if(!$return) {
                if($uid == -1) {
                    showmessage('profile_username_illegal');
                } elseif($uid == -2) {
                    showmessage('profile_username_protect');
                } elseif($uid == -3) {
                    showmessage('profile_username_duplicate');
                } elseif($uid == -4) {
                    showmessage('profile_email_illegal');
                } elseif($uid == -5) {
                    showmessage('profile_email_domain_illegal');
                } elseif($uid == -6) {
                    showmessage('profile_email_duplicate');
                } else {
                    showmessage('undefined_action');
                }
            } else {
                return;
            }
        }

        $init_arr = array('credits' => explode(',', $_G['setting']['initcredits']));
        C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);

        if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
            C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72)*3600);
            if($_G['setting']['regctrl']) {
                C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
            }
        }

        if($_G['setting']['regverify'] == 2) {
            C::t('common_member_validate')->insert(array(
                'uid' => $uid,
                'submitdate' => $_G['timestamp'],
                'moddate' => 0,
                'admin' => '',
                'submittimes' => 1,
                'status' => 0,
                'message' => '',
                'remark' => '',
            ), false, true);
            manage_addnotify('verifyuser');
        }
        require_once libfile('function/member');
        setloginstatus(array(
            'uid' => $uid,
            'username' => $username,
            'password' => $password,
            'groupid' => $groupid,
        ), 0);

        include_once libfile('function/stat');
        updatestat('register');

        return $uid;
    }

}
?>