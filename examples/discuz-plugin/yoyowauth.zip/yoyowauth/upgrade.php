<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


//各种升级操作


$finish = TRUE;