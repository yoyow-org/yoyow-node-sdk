function yyw_login_button_click(link) {
    var back = location.href;
    location.href=(link?link:'/')+'plugin.php?id=yoyowauth:login&op=init&state='+escape(back);
}