<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = !empty($_GET['op']) ? $_GET['op'] : '';
if(!in_array($op, array('init', 'callback', 'update','unbind','regcallback'))) {
    showmessage('undefined_action');
}

require_once DISCUZ_ROOT . './source/plugin/yoyowauth/YOYOW_Auth.php';

$yyw = new YOYOW_Auth();

if($op == 'init') {
    $yyw->login();
}else if($op == 'callback'){
    if(!isset($_GET['yoyow'])||!isset($_GET['time'])||!isset($_GET['sign'])){
        dheader('Location:'.$_G['siteurl']);
        dexit();
    }
    $yyw->callback($_GET['yoyow'],$_GET['time'],$_GET['sign'],$_GET['state']);
}else if($op == 'update'){

}else if($op == 'unbind'){
    $yyw->unbind_user();
}else if($op == 'regcallback'){
    $yoyow = getcookie('yyw_account');
    $time = getcookie('yyw_time');
    $sign = getcookie('yyw_sign');
    if(!empty($yoyow)&&!empty($time)&&!empty($sign)){
        dsetcookie('yyw_account');
        dsetcookie('yyw_time');
        dsetcookie('yyw_sign');
        C::t('#yoyowauth#common_member_yoyowauth')->insert(array(
            'uid'=>$_G['uid'],
            'yoyow'=>$yoyow
        ));
        C::t('common_member')->update($_G['uid'], array('conisbind' => '1'));
        $yyw->callback($yoyow,$time,$sign,dreferer());
    }
}