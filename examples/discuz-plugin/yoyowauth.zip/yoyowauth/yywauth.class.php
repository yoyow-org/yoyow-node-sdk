<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_yoyowauth {

    function plugin_yoyowauth(){
        include_once template('yoyowauth:module');
    }

    function global_header(){
        return "<script src='source/plugin/yoyowauth/template/yoyowauth.js'></script>";
    }

    function global_login_extra() {
        global $_G;
        if($_G['inshowmessage'] || !$_G['cache']['plugin']['yoyowauth']['show_button']) {
            return;
        }
        return yyw_tpl_global_login_extra();
    }

    function global_usernav_extra1() {
        global $_G;
        if(!$_G['cache']['plugin']['yoyowauth']['show_button']) {
            return;
        }
        if (!$_G['uid']) {
            return;
        }
        if(!$_G['member']['conisbind']) {
            return yyw_tpl_global_usernav_extra1();
        }
    }

}
?>