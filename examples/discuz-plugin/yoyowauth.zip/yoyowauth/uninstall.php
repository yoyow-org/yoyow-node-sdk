<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/*
C::t('common_setting')->delete('yoyowauth');
updatecache('setting');
*/

$finish = TRUE;