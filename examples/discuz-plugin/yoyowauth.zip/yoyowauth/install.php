<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_common_member_yoyowauth` (
  `uid` mediumint(8) NOT NULL DEFAULT '0' COMMENT 'dz中用户id',
  `yoyow` varchar(50) NOT NULL DEFAULT '' COMMENT 'yoyow账号',
  `bindtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '绑定时间',
  PRIMARY KEY (`uid`),
  KEY `yoyow` (`yoyow`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
EOF;

runquery($sql);


$finish = TRUE;